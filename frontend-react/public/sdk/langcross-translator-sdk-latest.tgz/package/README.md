# 翻译助手 langcross TypeScript SDK

与 Python SDK 完全一致的开放 API 客户端。

```bash
npm install
npm run build   # 产出 dist/（CommonJS + d.ts）
```

```ts
import { TranslatorClient } from "@langcross/translator-sdk";

const c = new TranslatorClient("https://translator.example.com", "YOUR_API_KEY");
const task = await c.translateAndWait("Hello world", ["zh"]);
console.log(task.status, task.files);
```

约束（同 Python SDK）：
- 成功响应**不含** `success` 字段，以 `task_id` 存在为准；
- 业务错误为 `{success:false, error_code, message}` 或 HTTP 4xx/5xx；
- 所有计量按积分展示，受租户余额与每日配额约束。

## 文本任务完成后的读数（2026-11-03 合规批）

`getTask()` / `translateAndWait()` 的返回类型 `TaskStatus` 里带这几组键（都在完成态才出现）：

| 键 | 含义 |
|---|---|
| `translations` | 语言码 → 译文 |
| `sources` | 语言码 → 来源档，取值见 `SourceKind`：`kb` / `model` / `model_with_source_fallback` / `upstream_failed` / `approved` / `compliance_skipped` |
| `unresolved_lines` | 语言码 → 按原文交付的行数（**键缺席＝没有未译出行**，接口不会下发 0 或 null） |
| `upstream_dead_lines` | 其中判上游不可用的行数 |
| `truncated_lines` | 其中被模型输出截断的行数 |
| `compliance_skipped` | 语言码 → **按内容合规要求跳过翻译**的处数（键缺席＝没有跳过） |
| `compliance_items` | 合规跳过的逐条素材：`{lang, line, side, terms?, lead?}` |

**两组计数互斥**，请不要合并统计：前三个（`unresolved_*` / `upstream_dead_*` / `truncated_*`）答的是
「想翻却没翻出来」，`compliance_skipped` 答的是「平台按合规要求决定不翻」——后者不是缺陷，
把它算进「漏译」会让您按一个不存在的缺口去补单。

`compliance_items[].side` 只有两个值：`input`（源文命中 ⇒ 该行不进模型、`terms` 回显命中的词面）
与 `output`（模型自产违禁译文 ⇒ 该行译文被丢弃、**不回显词面**）。`lead` 是平台统一下发的一句处置说明，
可直接展示给终端读者，**不要自行改写或本地转录**（平台改口径时您的文案会与事实脱节）。

