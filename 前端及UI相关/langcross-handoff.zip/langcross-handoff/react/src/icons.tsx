import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function base({ size = 16, ...rest }: IconProps): SVGProps<SVGSVGElement> {
  return {
    width: size,
    height: size,
    viewBox: "0 0 16 16",
    fill: "none",
    "aria-hidden": true,
    ...rest,
  };
}

/** 对勾（描边 2 纯白 —— 与同行图标对齐光学重量） */
export function CheckIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <path d="M3.5 8.4L6.6 11.5L12.5 4.9" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/** 下载（16×16 / 描边 1.9：竖线 + 折箭头 + 托盘） */
export function DownloadIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <path d="M8 1.9v8" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" />
      <path d="M4.7 7.2L8 10.5l3.3-3.3" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" />
      <path d="M2.6 11.3v1.3c0 .6.5 1.1 1.1 1.1h8.6c.6 0 1.1-.5 1.1-1.1v-1.3" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/** Toast 成功（圆圈勾，白） */
export function ToastSuccessIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <circle cx="8" cy="8" r="6.6" stroke="currentColor" strokeWidth={1.6} />
      <path d="M5.2 8.3L7.2 10.3L10.9 5.9" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/** Toast 失败（圆圈叉，红） */
export function ToastErrorIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <circle cx="8" cy="8" r="6.6" stroke="currentColor" strokeWidth={1.6} />
      <path d="M5.6 5.6L10.4 10.4M10.4 5.6L5.6 10.4" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" />
    </svg>
  );
}

/** Toast 警告（圆圈叹号，琥珀） */
export function ToastWarnIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <circle cx="8" cy="8" r="6.6" stroke="currentColor" strokeWidth={1.6} />
      <path d="M8 4.8v3.6" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" />
      <circle cx="8" cy="11" r="0.9" fill="currentColor" />
    </svg>
  );
}

/** 关闭 ×（12） */
export function CloseIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <path d="M2.5 2.5L9.5 9.5M9.5 2.5L2.5 9.5" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" />
    </svg>
  );
}

/** 下拉箭头（12） */
export function CaretDownIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
