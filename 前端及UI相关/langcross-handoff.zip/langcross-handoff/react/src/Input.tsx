import { useId } from "react";
import type { InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { CaretDownIcon } from "./icons";

export interface FieldProps {
  label?: ReactNode;
  error?: ReactNode;
  children: ReactNode;
  /** 传给 .lc-field 的额外类名 */
  className?: string;
}

/** 字段容器：12px 标签 + 控件 + 12px 错误文案（错误态描边由控件自己的 error 类负责） */
export function Field({ label, error, className = "", children }: FieldProps) {
  return (
    <div className={`lc-field ${className}`.trim()}>
      {label ? <span className="lc-field__label">{label}</span> : null}
      {children}
      {error ? <span className="lc-field__error" role="alert">{error}</span> : null}
    </div>
  );
}

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  /** 传入即进入错误态（描边 #E5484D） */
  error?: boolean;
}

export function Input({ error = false, className = "", ...rest }: InputProps) {
  const cls = ["lc-input", error ? "lc-input--error" : "", className].filter(Boolean).join(" ");
  return <input className={cls} {...rest} />;
}

export function Textarea({ className = "", ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={`lc-textarea ${className}`.trim()} {...rest} />;
}

export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  /** 展示值（胶囊文案）；原生 select 负责交互，样式走 .lc-select */
  display?: ReactNode;
}

/** 语种胶囊样式选择器（ZH → EN 之类）；选项用原生 select 保证可访问性 */
export function Select({ display, className = "", children, ...rest }: SelectProps) {
  return (
    <span className={`lc-select ${className}`.trim()} style={{ position: "relative" }}>
      <select
        {...rest}
        style={{
          appearance: "none",
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          opacity: 0,
          cursor: "pointer",
          border: 0,
        }}
      >
        {children}
      </select>
      {display}
      <CaretDownIcon size={12} />
    </span>
  );
}
