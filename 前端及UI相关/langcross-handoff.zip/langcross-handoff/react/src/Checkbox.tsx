import type { InputHTMLAttributes, ReactNode } from "react";

export interface CheckboxProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: ReactNode;
}

/**
 * 复选框。选中态白底黑勾（X/Grok 单色，--lc-success）。
 * label 13px #E7E9EA；disabled 时文字交给调用方用 --lc-disabled。
 */
export function Checkbox({ label, className = "", style, ...rest }: CheckboxProps) {
  return (
    <label className={`lc-check-row ${className}`.trim()} style={{ display: "inline-flex", alignItems: "center", gap: 10, ...style }}>
      <input type="checkbox" className="lc-checkbox" {...rest} />
      {label ? <span style={{ fontSize: 13, color: rest.disabled ? "var(--lc-disabled)" : "var(--lc-text)" }}>{label}</span> : null}
    </label>
  );
}

export interface SwitchProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: ReactNode;
  /** label 放在开关右侧（规范布局） */
}

/** 开关：36×20 轨道，选中白底黑球右移；label 在右。 */
export function Switch({ label, className = "", style, ...rest }: SwitchProps) {
  return (
    <label className={`lc-switch-row ${className}`.trim()} style={{ display: "inline-flex", alignItems: "center", gap: 10, ...style }}>
      <input type="checkbox" role="switch" className="lc-switch" {...rest} />
      {label ? <span style={{ fontSize: 13, color: rest.disabled ? "var(--lc-disabled)" : rest.checked ? "var(--lc-text)" : "var(--lc-text-2)" }}>{label}</span> : null}
    </label>
  );
}
